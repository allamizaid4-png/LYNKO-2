# Add narrowly-scoped keep rules only when a release build requires them.
